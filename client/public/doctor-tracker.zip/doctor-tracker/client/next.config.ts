import type { NextConfig } from "next";

// The browser only ever talks to this origin. `/api/*` is proxied to the Express server, so the
// httpOnly auth cookie is first-party (works in Safari / with third-party cookies blocked).
const API_URL = process.env.API_URL ?? "http://localhost:4000";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${API_URL}/api/:path*` }];
  },
};

export default nextConfig;
