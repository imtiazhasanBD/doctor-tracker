import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";

export const metadata: Metadata = { title: "Doctor" };

export default function DoctorDetailPage() {
  return <ComingSoon title="Doctor details" description="Patients under this doctor, with add and remove." />;
}
