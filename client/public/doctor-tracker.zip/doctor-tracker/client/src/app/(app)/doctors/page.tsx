import type { Metadata } from "next";
import { Suspense } from "react";
import { DoctorsPageSkeleton } from "@/components/doctors/doctors-skeleton";
import { DoctorsView } from "@/components/doctors/doctors-view";

export const metadata: Metadata = { title: "Doctors" };

export default function DoctorsPage() {
  // useSearchParams (table state lives in the URL) must sit inside a Suspense boundary.
  return (
    <Suspense fallback={<DoctorsPageSkeleton />}>
      <DoctorsView />
    </Suspense>
  );
}
