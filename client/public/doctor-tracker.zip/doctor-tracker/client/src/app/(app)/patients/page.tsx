import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";

export const metadata: Metadata = { title: "Patients" };

export default function PatientsPage() {
  return <ComingSoon title="Patients" description="Search, filter and edit every patient." />;
}
