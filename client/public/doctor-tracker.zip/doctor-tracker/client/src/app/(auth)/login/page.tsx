import type { Metadata } from "next";
import { Suspense } from "react";
import { Activity, BarChart3, ShieldCheck, Stethoscope } from "lucide-react";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = { title: "Sign in" };

const POINTS = [
  { icon: Activity, text: "Track doctors and their patients in one place" },
  { icon: BarChart3, text: "Live analytics, charts and date-based insights" },
  { icon: ShieldCheck, text: "Secure, session-based admin access" },
];

export default function LoginPage() {
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <aside className="relative hidden overflow-hidden bg-primary p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute -top-24 -right-24 size-96 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 size-96 rounded-full bg-black/10 blur-3xl" />
        <div className="relative flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center rounded-lg bg-white/15">
            <Stethoscope className="size-5" />
          </span>
          <span className="text-lg font-semibold tracking-tight">Doctor Tracker</span>
        </div>
        <div className="relative space-y-8">
          <h2 className="max-w-md text-4xl leading-tight font-semibold tracking-tight">Everything about your doctors and patients, at a glance.</h2>
          <ul className="space-y-4">
            {POINTS.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-3 text-primary-foreground/90">
                <span className="flex size-8 items-center justify-center rounded-md bg-white/15">
                  <Icon className="size-4" />
                </span>
                {text}
              </li>
            ))}
          </ul>
        </div>
        <p className="relative text-sm text-primary-foreground/70">Administrative portal</p>
      </aside>

      <main className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <Suspense>
            <LoginForm />
          </Suspense>
        </div>
      </main>
    </div>
  );
}
