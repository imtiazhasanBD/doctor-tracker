"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, Loader2, Stethoscope } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { useLogin, useMe } from "@/hooks/use-auth";
import { ApiError } from "@/lib/api";
import { loginSchema, type LoginValues } from "@/lib/validators";

const DEMO_EMAIL = process.env.NEXT_PUBLIC_DEMO_EMAIL;
const DEMO_PASSWORD = process.env.NEXT_PUBLIC_DEMO_PASSWORD;

/** Only allow same-site relative redirects (blocks `?next=https://evil.com` and `//evil.com`). */
function safeNext(next: string | null) {
  return next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";
}

export function LoginForm() {
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const [showPassword, setShowPassword] = useState(false);
  const login = useLogin();
  const me = useMe();

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors },
  } = useForm<LoginValues>({ resolver: zodResolver(loginSchema), defaultValues: { email: "", password: "" } });

  // Already signed in (valid session)? Skip the form.
  useEffect(() => {
    if (me.data) router.replace(next);
  }, [me.data, next, router]);

  const onSubmit = handleSubmit(async (values) => {
    try {
      await login.mutateAsync(values);
      router.replace(next);
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Can't reach the server. Please try again.";
      setError("root", { message });
    }
  });

  const rootError = errors.root?.message;
  const busy = login.isPending || login.isSuccess;

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <div className="mb-6 flex size-11 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-xs lg:hidden">
          <Stethoscope className="size-6" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1>
        <p className="text-sm text-muted-foreground">Sign in to manage doctors and patients.</p>
      </div>

      <form onSubmit={onSubmit} noValidate className="space-y-4">
        {rootError ? (
          <div role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {rootError}
          </div>
        ) : null}

        <Field label="Email" htmlFor="email" error={errors.email?.message}>
          <Input id="email" type="email" autoComplete="username" placeholder="you@example.com" aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-error" : undefined} {...register("email")} />
        </Field>

        <Field label="Password" htmlFor="password" error={errors.password?.message}>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              className="pr-10"
              aria-invalid={!!errors.password}
              aria-describedby={errors.password ? "password-error" : undefined}
              {...register("password")}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              aria-label={showPassword ? "Hide password" : "Show password"}
              className="absolute top-1/2 right-2 flex size-7 -translate-y-1/2 cursor-pointer items-center justify-center rounded-sm text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </Field>

        <Button type="submit" className="w-full" size="lg" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" /> : null}
          {busy ? "Signing in…" : "Sign in"}
        </Button>
      </form>

      {DEMO_EMAIL && DEMO_PASSWORD ? (
        <div className="rounded-lg border border-dashed bg-muted/40 p-4 text-sm">
          <p className="font-medium">Demo access</p>
          <p className="mt-1 text-muted-foreground">
            {DEMO_EMAIL} · {DEMO_PASSWORD}
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => {
              setValue("email", DEMO_EMAIL, { shouldValidate: true });
              setValue("password", DEMO_PASSWORD, { shouldValidate: true });
            }}
          >
            Fill demo credentials
          </Button>
        </div>
      ) : null}
    </div>
  );
}
