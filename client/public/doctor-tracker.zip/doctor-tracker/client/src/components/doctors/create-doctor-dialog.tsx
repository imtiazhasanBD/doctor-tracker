"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { useCreateDoctor, useDoctorFilterOptions } from "@/hooks/use-doctors";
import { ApiError } from "@/lib/api";
import { doctorName } from "@/lib/utils";
import { doctorSchema, type DoctorValues } from "@/lib/validators";

const FIELDS: (keyof DoctorValues)[] = ["name", "specialization", "hospital", "phone", "email"];
const EMPTY: DoctorValues = { name: "", specialization: "", hospital: "", phone: "", email: "" };

export function CreateDoctorDialog() {
  const [open, setOpen] = useState(false);
  const createDoctor = useCreateDoctor();
  const { data: options } = useDoctorFilterOptions();

  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm<DoctorValues>({ resolver: zodResolver(doctorSchema), defaultValues: EMPTY });

  const onSubmit = handleSubmit(async (values) => {
    try {
      const doctor = await createDoctor.mutateAsync(values);
      toast.success(`${doctorName(doctor.name)} was added`);
      setOpen(false);
      reset(EMPTY);
    } catch (error) {
      if (!(error instanceof ApiError)) {
        toast.error("Can't reach the server. Please try again.");
        return;
      }
      // Map server-side field errors (422 validation, 409 duplicate email) onto the matching inputs.
      const mapped = error.errors.filter((e) => FIELDS.includes(e.path as keyof DoctorValues));
      mapped.forEach((e) => setError(e.path as keyof DoctorValues, { message: e.message }));
      if (mapped.length === 0) setError("root", { message: error.message });
    }
  });

  const field = (name: keyof DoctorValues) => ({
    id: `doctor-${name}`,
    "aria-invalid": !!errors[name],
    "aria-describedby": errors[name] ? `doctor-${name}-error` : undefined,
    ...register(name),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset(EMPTY);
      }}
    >
      <DialogTrigger asChild>
        <Button>
          <Plus /> Add doctor
        </Button>
      </DialogTrigger>

      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add doctor</DialogTitle>
          <DialogDescription>Create a new doctor profile. You can add patients after saving.</DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} noValidate className="grid gap-4">
          {errors.root?.message ? (
            <div role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {errors.root.message}
            </div>
          ) : null}

          <Field label="Full name" htmlFor="doctor-name" error={errors.name?.message} hint="Without the title – “Dr.” is added automatically.">
            <Input placeholder="Amina Rahman" autoComplete="off" {...field("name")} />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Specialization" htmlFor="doctor-specialization" error={errors.specialization?.message}>
              <Input placeholder="Cardiology" list="specialization-options" autoComplete="off" {...field("specialization")} />
              <datalist id="specialization-options">{options?.specializations.map((s) => <option key={s} value={s} />)}</datalist>
            </Field>
            <Field label="Hospital" htmlFor="doctor-hospital" error={errors.hospital?.message}>
              <Input placeholder="City General Hospital" list="hospital-options" autoComplete="off" {...field("hospital")} />
              <datalist id="hospital-options">{options?.hospitals.map((h) => <option key={h} value={h} />)}</datalist>
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Phone" htmlFor="doctor-phone" error={errors.phone?.message}>
              <Input type="tel" placeholder="+880 1700 000000" autoComplete="off" {...field("phone")} />
            </Field>
            <Field label="Email" htmlFor="doctor-email" error={errors.email?.message}>
              <Input type="email" placeholder="doctor@hospital.com" autoComplete="off" {...field("email")} />
            </Field>
          </div>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createDoctor.isPending}>
              {createDoctor.isPending ? <Loader2 className="animate-spin" /> : null}
              Save doctor
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
