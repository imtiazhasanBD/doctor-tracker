"use client";

import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/native-select";
import { SearchInput } from "@/components/shared/search-input";
import { useDoctorFilterOptions } from "@/hooks/use-doctors";
import type { DoctorListParams } from "@/lib/types";

export function DoctorFilters({ params, onChange }: { params: DoctorListParams; onChange: (patch: Record<string, string>) => void }) {
  const { data: options } = useDoctorFilterOptions();

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-12">
      <div className="sm:col-span-2 lg:col-span-4">
        <Field label="Search" htmlFor="doctor-search">
          <SearchInput id="doctor-search" value={params.search} onChange={(search) => onChange({ search })} placeholder="Search by name…" />
        </Field>
      </div>

      <div className="lg:col-span-2">
        <Field label="Specialization" htmlFor="doctor-specialization">
          <NativeSelect id="doctor-specialization" value={params.specialization} onChange={(e) => onChange({ specialization: e.target.value })}>
            <option value="">All</option>
            {options?.specializations.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </NativeSelect>
        </Field>
      </div>

      <div className="lg:col-span-2">
        <Field label="Hospital" htmlFor="doctor-hospital">
          <NativeSelect id="doctor-hospital" value={params.hospital} onChange={(e) => onChange({ hospital: e.target.value })}>
            <option value="">All</option>
            {options?.hospitals.map((h) => (
              <option key={h} value={h}>
                {h}
              </option>
            ))}
          </NativeSelect>
        </Field>
      </div>

      <div className="lg:col-span-2">
        <Field label="Added from" htmlFor="doctor-from">
          <Input id="doctor-from" type="date" value={params.from} max={params.to || undefined} onChange={(e) => onChange({ from: e.target.value })} />
        </Field>
      </div>

      <div className="lg:col-span-2">
        <Field label="Added to" htmlFor="doctor-to">
          <Input id="doctor-to" type="date" value={params.to} min={params.from || undefined} onChange={(e) => onChange({ to: e.target.value })} />
        </Field>
      </div>
    </div>
  );
}
