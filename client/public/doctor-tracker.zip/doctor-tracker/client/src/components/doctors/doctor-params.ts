import { DOCTOR_SORTS, type DoctorListParams, type DoctorSort } from "@/lib/types";

export const PAGE_SIZES = [10, 25, 50];
export const FILTER_KEYS = ["search", "specialization", "hospital", "from", "to"] as const;

export const SORT_LABELS: Record<DoctorSort, string> = {
  newest: "Newest first",
  oldest: "Oldest first",
  name: "Name (A–Z)",
  patients: "Most patients",
};

/** URL -> validated list params (bad values fall back to defaults instead of erroring). */
export function parseDoctorParams(sp: URLSearchParams): DoctorListParams {
  const limit = Number(sp.get("limit"));
  const sort = sp.get("sort") as DoctorSort;
  return {
    page: Math.max(1, Math.floor(Number(sp.get("page"))) || 1),
    limit: PAGE_SIZES.includes(limit) ? limit : PAGE_SIZES[0]!,
    search: sp.get("search") ?? "",
    specialization: sp.get("specialization") ?? "",
    hospital: sp.get("hospital") ?? "",
    from: sp.get("from") ?? "",
    to: sp.get("to") ?? "",
    sort: DOCTOR_SORTS.includes(sort) ? sort : "newest",
  };
}

export const countActiveFilters = (p: DoctorListParams) => FILTER_KEYS.filter((key) => p[key] !== "").length;
