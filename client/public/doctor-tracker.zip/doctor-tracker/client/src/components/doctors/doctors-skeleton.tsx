import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function DoctorRowsSkeleton({ rows = 8 }: { rows?: number }) {
  return (
    <div aria-busy="true" aria-label="Loading doctors" className="divide-y">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="flex items-center gap-4 px-4 py-3.5">
          <Skeleton className="size-9 shrink-0 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-40" />
            <Skeleton className="h-3 w-52 max-w-full" />
          </div>
          <Skeleton className="hidden h-5 w-24 rounded-full md:block" />
          <Skeleton className="hidden h-4 w-36 lg:block" />
          <Skeleton className="h-6 w-8" />
        </div>
      ))}
    </div>
  );
}

/** Suspense fallback for the whole page (useSearchParams needs a boundary). */
export function DoctorsPageSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-4 w-72 max-w-full" />
      </div>
      <Card className="p-4">
        <Skeleton className="h-[60px] w-full" />
      </Card>
      <Card>
        <DoctorRowsSkeleton />
      </Card>
    </div>
  );
}
