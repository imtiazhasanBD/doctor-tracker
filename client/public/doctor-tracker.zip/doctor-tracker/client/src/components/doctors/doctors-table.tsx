import { memo } from "react";
import Link from "next/link";
import { Mail, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { InitialsAvatar } from "@/components/shared/initials-avatar";
import type { Doctor } from "@/lib/types";
import { doctorName, formatDate } from "@/lib/utils";

const DoctorRow = memo(function DoctorRow({ doctor }: { doctor: Doctor }) {
  return (
    <TableRow className="relative">
      <TableCell>
        <div className="flex items-center gap-3">
          <InitialsAvatar name={doctor.name} />
          <div className="min-w-0">
            {/* Stretched link: the whole row is clickable, but the accessible target is just the name. */}
            <Link href={`/doctors/${doctor._id}`} prefetch={false} className="font-medium outline-none after:absolute after:inset-0 hover:underline focus-visible:underline">
              {doctorName(doctor.name)}
            </Link>
            <p className="truncate text-xs text-muted-foreground">{doctor.email}</p>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <Badge>{doctor.specialization}</Badge>
      </TableCell>
      <TableCell className="text-muted-foreground">{doctor.hospital}</TableCell>
      <TableCell className="whitespace-nowrap text-muted-foreground">{doctor.phone}</TableCell>
      <TableCell className="text-right">
        <span className="inline-flex min-w-8 justify-center rounded-md bg-muted px-2 py-0.5 text-sm font-medium tabular-nums">{doctor.patientCount}</span>
      </TableCell>
      <TableCell className="whitespace-nowrap text-muted-foreground">{formatDate(doctor.createdAt)}</TableCell>
    </TableRow>
  );
});

export function DoctorsTable({ doctors }: { doctors: Doctor[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow className="hover:bg-transparent">
          <TableHead>Doctor</TableHead>
          <TableHead>Specialization</TableHead>
          <TableHead>Hospital</TableHead>
          <TableHead>Phone</TableHead>
          <TableHead className="text-right">Patients</TableHead>
          <TableHead>Added</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {doctors.map((doctor) => (
          <DoctorRow key={doctor._id} doctor={doctor} />
        ))}
      </TableBody>
    </Table>
  );
}

const DoctorCard = memo(function DoctorCard({ doctor }: { doctor: Doctor }) {
  return (
    <li>
      <Link href={`/doctors/${doctor._id}`} prefetch={false} className="block space-y-3 p-4 transition-colors outline-none hover:bg-muted/50 focus-visible:bg-muted/50">
        <div className="flex items-start gap-3">
          <InitialsAvatar name={doctor.name} />
          <div className="min-w-0 flex-1">
            <p className="font-medium">{doctorName(doctor.name)}</p>
            <p className="text-xs text-muted-foreground">{doctor.hospital}</p>
          </div>
          <span className="rounded-md bg-muted px-2 py-0.5 text-sm font-medium tabular-nums" aria-label={`${doctor.patientCount} patients`}>
            {doctor.patientCount}
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <Badge>{doctor.specialization}</Badge>
          <span className="inline-flex items-center gap-1">
            <Phone className="size-3" /> {doctor.phone}
          </span>
          <span className="inline-flex items-center gap-1 break-all">
            <Mail className="size-3" /> {doctor.email}
          </span>
        </div>
      </Link>
    </li>
  );
});

/** Below `md` the table becomes a list of cards. */
export function DoctorCards({ doctors }: { doctors: Doctor[] }) {
  return (
    <ul className="divide-y">
      {doctors.map((doctor) => (
        <DoctorCard key={doctor._id} doctor={doctor} />
      ))}
    </ul>
  );
}
