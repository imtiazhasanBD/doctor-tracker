"use client";

import { useEffect, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { SearchX, Stethoscope, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { NativeSelect } from "@/components/ui/native-select";
import { EmptyState } from "@/components/shared/empty-state";
import { ErrorState } from "@/components/shared/error-state";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { doctorListOptions, useDoctors } from "@/hooks/use-doctors";
import { useUrlState } from "@/hooks/use-url-state";
import { DOCTOR_SORTS } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CreateDoctorDialog } from "./create-doctor-dialog";
import { DoctorFilters } from "./doctor-filters";
import { FILTER_KEYS, PAGE_SIZES, SORT_LABELS, countActiveFilters, parseDoctorParams } from "./doctor-params";
import { DoctorRowsSkeleton } from "./doctors-skeleton";
import { DoctorCards, DoctorsTable } from "./doctors-table";

export function DoctorsView() {
  const { searchParams, update, clear } = useUrlState();
  const params = useMemo(() => parseDoctorParams(searchParams), [searchParams]);
  const queryClient = useQueryClient();

  const { data, isPending, isError, error, isFetching, isPlaceholderData, refetch } = useDoctors(params);
  const activeFilters = countActiveFilters(params);

  // Warm the cache for the next page so "Next" feels instant.
  useEffect(() => {
    if (data && params.page < data.totalPages) {
      void queryClient.prefetchQuery(doctorListOptions({ ...params, page: params.page + 1 }));
    }
  }, [data, params, queryClient]);

  // A stale/hand-edited ?page=99 snaps back to the last real page.
  useEffect(() => {
    if (data && !isPlaceholderData && params.page > data.totalPages) update({ page: data.totalPages });
  }, [data, isPlaceholderData, params.page, update]);

  const hasRows = !!data && data.data.length > 0;

  return (
    <div className="space-y-6">
      <PageHeader title="Doctors" description="Manage doctors and see how many patients each one has." actions={<CreateDoctorDialog />} />

      <Card className="p-4">
        <DoctorFilters params={params} onChange={update} />
      </Card>

      <Card className="gap-0 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b px-4 py-3">
          <div className="flex items-center gap-3">
            <p className="text-sm text-muted-foreground" aria-live="polite">
              {data ? (
                <>
                  <span className="font-medium text-foreground">{data.total.toLocaleString()}</span> {data.total === 1 ? "doctor" : "doctors"}
                </>
              ) : (
                "Loading…"
              )}
            </p>
            {activeFilters > 0 ? (
              <Button variant="ghost" size="sm" className="h-7 text-muted-foreground" onClick={() => clear([...FILTER_KEYS])}>
                <X /> Clear filters ({activeFilters})
              </Button>
            ) : null}
          </div>

          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            Sort
            <NativeSelect aria-label="Sort doctors" value={params.sort} onChange={(e) => update({ sort: e.target.value === "newest" ? "" : e.target.value })} className="h-8 w-40">
              {DOCTOR_SORTS.map((sort) => (
                <option key={sort} value={sort}>
                  {SORT_LABELS[sort]}
                </option>
              ))}
            </NativeSelect>
          </label>
        </div>

        {isPending ? (
          <DoctorRowsSkeleton rows={params.limit > 10 ? 10 : params.limit} />
        ) : isError ? (
          <ErrorState message={error.message} onRetry={() => void refetch()} />
        ) : !hasRows ? (
          activeFilters > 0 ? (
            <EmptyState
              icon={<SearchX />}
              title="No doctors match your filters"
              description="Try a different search term or widen the date range."
              action={
                <Button variant="outline" size="sm" onClick={() => clear([...FILTER_KEYS])}>
                  Clear filters
                </Button>
              }
            />
          ) : (
            <EmptyState icon={<Stethoscope />} title="No doctors yet" description="Add your first doctor to get started." action={<CreateDoctorDialog />} />
          )
        ) : (
          // Stays mounted (dimmed) while the next page loads: no layout jump, no flicker.
          <div className={cn("transition-opacity", isFetching && "opacity-60")} aria-busy={isFetching}>
            <div className="hidden md:block">
              <DoctorsTable doctors={data.data} />
            </div>
            <div className="md:hidden">
              <DoctorCards doctors={data.data} />
            </div>
          </div>
        )}

        {data && data.total > 0 ? (
          <Pagination
            page={params.page}
            limit={params.limit}
            total={data.total}
            totalPages={data.totalPages}
            limits={PAGE_SIZES}
            disabled={isPlaceholderData}
            onPageChange={(page) => update({ page })}
            onLimitChange={(limit) => update({ limit: limit === PAGE_SIZES[0] ? "" : limit })}
          />
        ) : null}
      </Card>
    </div>
  );
}
