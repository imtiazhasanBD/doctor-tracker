import { Construction } from "lucide-react";
import { Card } from "@/components/ui/card";
import { EmptyState } from "./empty-state";
import { PageHeader } from "./page-header";

export function ComingSoon({ title, description }: { title: string; description: string }) {
  return (
    <div className="space-y-6">
      <PageHeader title={title} description={description} />
      <Card>
        <EmptyState icon={<Construction />} title="Coming up next" description="This screen is built in the next step." />
      </Card>
    </div>
  );
}
