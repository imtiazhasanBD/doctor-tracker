import { cn, initials } from "@/lib/utils";

export function InitialsAvatar({ name, className }: { name: string; className?: string }) {
  return (
    <span
      aria-hidden
      className={cn("flex size-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary", className)}
    >
      {initials(name)}
    </span>
  );
}
