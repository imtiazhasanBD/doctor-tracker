"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NativeSelect } from "@/components/ui/native-select";
import { cn } from "@/lib/utils";

type PageItem = number | `gap-${number}`;

/** 1 … 4 5 [6] 7 8 … 20 */
export function getPageItems(page: number, totalPages: number): PageItem[] {
  if (totalPages <= 7) return Array.from({ length: totalPages }, (_, i) => i + 1);

  const set = new Set<number>([1, totalPages, page - 1, page, page + 1]);
  if (page <= 3) [2, 3, 4].forEach((n) => set.add(n));
  if (page >= totalPages - 2) [totalPages - 3, totalPages - 2, totalPages - 1].forEach((n) => set.add(n));

  const sorted = [...set].filter((n) => n >= 1 && n <= totalPages).sort((a, b) => a - b);
  const items: PageItem[] = [];
  sorted.forEach((n, i) => {
    if (i > 0 && n - sorted[i - 1]! > 1) items.push(`gap-${i}`);
    items.push(n);
  });
  return items;
}

export function Pagination({
  page,
  limit,
  total,
  totalPages,
  limits = [10, 25, 50],
  disabled,
  onPageChange,
  onLimitChange,
}: {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  limits?: number[];
  disabled?: boolean;
  onPageChange: (page: number) => void;
  onLimitChange: (limit: number) => void;
}) {
  const from = total === 0 ? 0 : (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);

  return (
    <div className="flex flex-col gap-3 border-t px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-sm text-muted-foreground">
        Showing <span className="font-medium text-foreground">{from}</span>–<span className="font-medium text-foreground">{to}</span> of{" "}
        <span className="font-medium text-foreground">{total.toLocaleString()}</span>
      </p>

      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm text-muted-foreground">
          Rows
          <NativeSelect
            aria-label="Rows per page"
            value={limit}
            onChange={(e) => onLimitChange(Number(e.target.value))}
            className="h-8 w-[4.5rem]"
          >
            {limits.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </NativeSelect>
        </label>

        <nav aria-label="Pagination" className="flex items-center gap-1">
          <Button variant="outline" size="icon" className="size-8" disabled={disabled || page <= 1} onClick={() => onPageChange(page - 1)} aria-label="Previous page">
            <ChevronLeft />
          </Button>

          <span className="px-2 text-sm text-muted-foreground sm:hidden">
            {page} / {totalPages}
          </span>

          <div className="hidden items-center gap-1 sm:flex">
            {getPageItems(page, totalPages).map((item) =>
              typeof item === "string" ? (
                <span key={item} className="px-1 text-muted-foreground" aria-hidden>
                  …
                </span>
              ) : (
                <Button
                  key={item}
                  variant={item === page ? "default" : "ghost"}
                  size="icon"
                  className={cn("size-8 text-[13px]", item !== page && "text-muted-foreground")}
                  disabled={disabled}
                  aria-current={item === page ? "page" : undefined}
                  aria-label={`Page ${item}`}
                  onClick={() => onPageChange(item)}
                >
                  {item}
                </Button>
              )
            )}
          </div>

          <Button variant="outline" size="icon" className="size-8" disabled={disabled || page >= totalPages} onClick={() => onPageChange(page + 1)} aria-label="Next page">
            <ChevronRight />
          </Button>
        </nav>
      </div>
    </div>
  );
}
