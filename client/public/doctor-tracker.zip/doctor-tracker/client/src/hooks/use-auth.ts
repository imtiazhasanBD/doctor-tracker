"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { User } from "@/lib/types";
import type { LoginValues } from "@/lib/validators";

export const authKeys = { me: ["auth", "me"] as const };

export function useMe() {
  return useQuery({
    queryKey: authKeys.me,
    queryFn: ({ signal }) => api<{ data: User }>("/auth/me", { signal }).then((r) => r.data),
    retry: false,
    staleTime: 5 * 60_000,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (credentials: LoginValues) =>
      api<{ data: User }>("/auth/login", { method: "POST", body: credentials }).then((r) => r.data),
    onSuccess: (user) => queryClient.setQueryData(authKeys.me, user),
  });
}

export function useLogout() {
  return useMutation({
    mutationFn: () => api("/auth/logout", { method: "POST" }),
    // Hard navigation: drops every cached query and any in-memory state.
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination -- intentional full reload
    onSettled: () => window.location.assign("/login"),
  });
}
