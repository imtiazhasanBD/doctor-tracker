"use client";

import { keepPreviousData, queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { Doctor, DoctorFilterOptions, DoctorListParams, Paginated } from "@/lib/types";
import type { DoctorValues } from "@/lib/validators";

export const doctorKeys = {
  all: ["doctors"] as const,
  list: (params: DoctorListParams) => [...doctorKeys.all, "list", params] as const,
  filters: () => [...doctorKeys.all, "filters"] as const,
};

export const doctorListOptions = (params: DoctorListParams) =>
  queryOptions({
    queryKey: doctorKeys.list(params),
    queryFn: ({ signal }) => api<Paginated<Doctor>>("/doctors", { query: { ...params }, signal }),
  });

/** keepPreviousData: the table stays on screen (dimmed) while the next page loads - no flicker. */
export function useDoctors(params: DoctorListParams) {
  return useQuery({ ...doctorListOptions(params), placeholderData: keepPreviousData });
}

export function useDoctorFilterOptions() {
  return useQuery({
    queryKey: doctorKeys.filters(),
    queryFn: ({ signal }) => api<{ data: DoctorFilterOptions }>("/doctors/filters", { signal }).then((r) => r.data),
    staleTime: 5 * 60_000,
  });
}

export function useCreateDoctor() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (values: DoctorValues) =>
      api<{ data: Doctor }>("/doctors", { method: "POST", body: values }).then((r) => r.data),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: doctorKeys.all }); // lists + filter options
      void queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
