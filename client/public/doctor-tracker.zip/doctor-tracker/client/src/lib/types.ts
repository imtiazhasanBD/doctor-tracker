export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface Doctor {
  _id: string;
  name: string;
  specialization: string;
  hospital: string;
  phone: string;
  email: string;
  patientCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Paginated<T> {
  data: T[];
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface DoctorFilterOptions {
  specializations: string[];
  hospitals: string[];
}

export const DOCTOR_SORTS = ["newest", "oldest", "name", "patients"] as const;
export type DoctorSort = (typeof DOCTOR_SORTS)[number];

export interface DoctorListParams {
  page: number;
  limit: number;
  search: string;
  specialization: string;
  hospital: string;
  from: string;
  to: string;
  sort: DoctorSort;
}
