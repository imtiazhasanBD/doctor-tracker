import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const dateFormatter = new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" });
export const formatDate = (iso: string | Date) => dateFormatter.format(new Date(iso));

export function initials(name: string) {
  return name
    .replace(/^dr\.?\s+/i, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]!.toUpperCase())
    .join("");
}

/** Doctors are stored without a title; add "Dr." for display (once). */
export const doctorName = (name: string) => (/^dr\.?\s/i.test(name) ? name : `Dr. ${name}`);
