import { z } from "zod";

// Mirrors the API's validation so users get instant feedback; the server remains the source of truth.
export const loginSchema = z.object({
  email: z.string().trim().min(1, "Enter your email").email("Enter a valid email"),
  password: z.string().min(1, "Enter your password"),
});
export type LoginValues = z.infer<typeof loginSchema>;

export const doctorSchema = z.object({
  name: z.string().trim().min(2, "Enter at least 2 characters").max(100, "Keep it under 100 characters"),
  specialization: z.string().trim().min(2, "Enter a specialization").max(100),
  hospital: z.string().trim().min(2, "Enter a hospital").max(150),
  phone: z
    .string()
    .trim()
    .regex(/^\+?[0-9\s\-()]{7,20}$/, "Enter a valid phone number"),
  email: z.string().trim().toLowerCase().email("Enter a valid email"),
});
export type DoctorValues = z.infer<typeof doctorSchema>;
