import { NextResponse, type NextRequest } from "next/server";

const COOKIE_NAME = "dt_token";

/**
 * Optimistic route guard: redirects to /login when there is no session cookie.
 * It does NOT verify the token - the Express API does that on every request (and a 401 sends the
 * user back to /login from the API client), so this is only a fast UX redirect, not the security boundary.
 */
export function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  if (pathname.startsWith("/login")) return NextResponse.next();

  if (!request.cookies.has(COOKIE_NAME)) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    url.searchParams.set("next", pathname + search);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  // Everything except the API proxy, Next internals and static files.
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
