import { connectDB, disconnectDB } from '../config/db';
import { Doctor } from '../models/Doctor';
import { Patient } from '../models/Patient';
import { SORTS as DOCTOR_SORTS, buildDoctorFilter } from '../services/doctor.service';
import { SORTS as PATIENT_SORTS, buildPatientFilter } from '../services/patient.service';
import { listDoctorsQuery } from '../validators/doctor.validators';
import { listPatientsQuery } from '../validators/patient.validators';

/** "LIMIT > FETCH > IXSCAN(index_name)" - stage names from the winning plan. */
function describePlan(plan: any): string {
  if (!plan) return '?';
  const label = plan.stage + (plan.indexName ? `(${plan.indexName})` : '');
  const children: any[] = plan.inputStage ? [plan.inputStage] : plan.inputStages ?? [];
  return children.length ? `${label} > ${children.map(describePlan).join(' + ')}` : label;
}

async function run(label: string, query: { explain: (v: string) => Promise<any> }) {
  const exp: any = await query.explain('executionStats');
  const s = exp.executionStats;
  return {
    query: label,
    plan: describePlan(exp.queryPlanner.winningPlan),
    keys: s.totalKeysExamined,
    docs: s.totalDocsExamined,
    returned: s.nReturned,
    ms: s.executionTimeMillis,
  };
}

// Queries are built with the SAME filter builders, sort maps and validators the API uses,
// so this table can't drift from what production requests actually execute.
const patients = (raw: Record<string, string>) => {
  const q = listPatientsQuery.parse(raw);
  return Patient.find(buildPatientFilter(q)).sort(PATIENT_SORTS[q.sort]).limit(q.limit) as any;
};
const doctors = (raw: Record<string, string>) => {
  const q = listDoctorsQuery.parse(raw);
  return Doctor.find(buildDoctorFilter(q)).sort(DOCTOR_SORTS[q.sort]).limit(q.limit) as any;
};

(async () => {
  await connectDB();
  const [nPatients, nDoctors] = await Promise.all([Patient.estimatedDocumentCount(), Doctor.estimatedDocumentCount()]);
  const busiest = await Doctor.findOne().sort({ patientCount: -1 }).lean();
  const today = new Date().toISOString().slice(0, 10);
  const monthAgo = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
  console.log(`Collections: ${nDoctors} doctors, ${nPatients} patients\n`);

  console.table([
    await run('patients: default list', patients({})),
    await run("patients: doctor's list", patients({ doctorId: String(busiest?._id) })),
    await run('patients: condition filter', patients({ condition: 'Diabetes' })),
    await run('patients: status filter', patients({ status: 'discharged' })),
    await run('patients: name prefix "an"', patients({ search: 'an' })),
    await run('patients: name prefix, sorted by name', patients({ search: 'an', sort: 'name' })),
    await run('patients: visit date range', patients({ from: monthAgo, to: today, sort: 'visit_desc' })),
    await run('patients: oldest first', patients({ sort: 'oldest' })),
    await run('doctors: default list', doctors({})),
    await run('doctors: specialization filter', doctors({ specialization: 'Cardiology' })),
    await run('doctors: name prefix', doctors({ search: 'a' })),
    await run('doctors: sorted by patient count', doctors({ sort: 'patients' })),
  ]);
  console.log('Every row should be IXSCAN with no SORT stage and docs ~= returned.');
  await disconnectDB();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
