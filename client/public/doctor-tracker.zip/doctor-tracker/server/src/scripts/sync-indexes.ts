import { connectDB, disconnectDB } from '../config/db';
import { Doctor } from '../models/Doctor';
import { Patient } from '../models/Patient';
import { User } from '../models/User';

// Makes the database's indexes match the schemas (drops stale ones, builds new ones). Does NOT touch data.
(async () => {
  await connectDB();
  for (const model of [User, Doctor, Patient]) {
    const dropped = await model.syncIndexes();
    console.log(`${model.modelName}: dropped [${dropped.join(', ')}]`);
  }
  await disconnectDB();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
